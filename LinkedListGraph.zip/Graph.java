package project4;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

import javax.swing.JOptionPane;

/*
 * this class does most of the work of the program and allows for the input of the textfile and the output of the correct classes
 */
public class Graph {

	static HashMap<String, Integer> classMap = new HashMap<>();
	static int numClasses=0;
	static LinkedList<Integer> graph[];
// this method takes in the 
	public static ArrayList<String> topologicalSort(String s) {

		boolean seen[] = new boolean[numClasses];
		boolean done[] = new boolean[numClasses];
		Stack<Integer> next = new Stack<>();
		DFS(seen, done, next, classMap.get(s));

		if (next.get(next.size() - 1) != -1 && next.size() > 0) {
			ArrayList<String> classOrder = new ArrayList<>();
			while (!next.empty()) {
				char convNum = (char) (65 + next.pop());
				classOrder.add("Class" + convNum);
			}
			return classOrder;
		}
		return null;
	}
// this recursive method is where the main concept of the program comes from, this allwos for the correct organisiation 
	public static void DFS(boolean seen[], boolean done[], Stack<Integer> next, int s) {
		if (seen[s]) {
			next.add(-1);
		} else if (done[s]) 
			return;		
		seen[s] = true;
		if (graph[s] != null) {
			for (Integer adj : graph[s]) { 
				DFS(seen, done, next, adj);
			}
		}
			done[s] = true;
			next.add(s);
		
	}
//this method takes in the name of the file and splits up the text by spaces as well as places them into an array
	public static boolean createGraph(String file) {
		try {
			Scanner in = new Scanner(new File(file));

			while (in.hasNext()) {
				String line = in.nextLine();
				String[] classes = line.split(" ");
				for (String className : classes) {
					classMap.put(className, className.charAt(className.length() - 1) - 'A');
				}
			}
			numClasses = classMap.size();
			graph = new LinkedList[numClasses];
			
			in = new Scanner(new File(file));
			while (in.hasNext()) {
				String line = in.nextLine();
				String[] classes = line.split("[ \n]");
				graph[classMap.get(classes[0])] = new LinkedList<>();
				for (int i = 1; i < classes.length; i++) {
					graph[classMap.get(classes[0])].add(classMap.get(classes[i]));
				}
			}
			return true;
		} catch (FileNotFoundException e) {
			System.out.print("could not find file");
			return false;
		}
	}

}
