package project4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;



import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.util.ArrayList;

/*
 * this class defines the user interface and allows for things to happen when the button is pressed
 */
	public class Interface extends JFrame implements ActionListener {

		JFrame frame = new JFrame();

		// labels
		JLabel inFile = new JLabel("Input File Name: ");
		JLabel classToComp = new JLabel("Class to Recompile: ");
		JLabel paneLabel = new JLabel("Recompilation Order");
		JLabel output = new JLabel();
		JLabel newLine = new JLabel("                                                "
				+ "                                                                  ");
		// textfields
		JTextField fileName = new JTextField(16);
		JTextField className = new JTextField(16);

		// the button
		JButton build = new JButton("Build Directed Graph");
		JButton top = new JButton("Topological Order");

		
		public Interface() {
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


			frame.setLayout(getLayout());
			Panel p1 = new Panel();
			Panel p2 = new Panel();
			Panel p3 = new Panel();
			Panel p4 = new Panel();

			frame.setSize(600, 350);

	// add the elements
			p1.add(inFile);
			p1.add(fileName);
			p1.add(build);

			p2.add(classToComp);
			p2.add(className);
			p2.add(top);


			
			p3.add(getContentPane().add(paneLabel));
				//p3.add(output);

			
			p4.add(p1);
			p4.add(p2);
			p4.add(p3);
			p4.add(newLine);
			p4.add(output);

			frame.add(p4);

			frame.setTitle("Class Dependency Graph");
			frame.setVisible(true);

		build.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				buildGraph(evt);
			}

		}); // makes the button do something
		top.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				topological(evt);
			}

		}); // makes the button do something

	}
		
		
		
		private void buildGraph(ActionEvent evt) {
			String file = fileName.getText();
			//boolean isbuild = Graph.createGraph(file);
				if(Graph.createGraph(file)) {
		            JOptionPane.showMessageDialog(null,"Graph sucessfully built","Message", 1);

				}else {
		            JOptionPane.showMessageDialog(null,"could not build graph","Message", 1);

				}
			}
			
			
		private void topological(ActionEvent evt) {

			String startClass = className.getText();
				ArrayList<String> compList = Graph.topologicalSort(startClass);
				if(compList.isEmpty()) {
		            JOptionPane.showMessageDialog(null,"cycle dected","Message", 1);
				}else {
					for(String className : compList) {
						output.setText(output.getText() + " " + className);
					}
				}
		}



		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	


