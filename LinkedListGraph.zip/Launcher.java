package project4;

public class Launcher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interface i = new Interface();
	}

}
